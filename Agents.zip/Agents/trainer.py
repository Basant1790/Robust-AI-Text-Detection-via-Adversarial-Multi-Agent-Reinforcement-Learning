# cobra/trainer.py
"""
COBRA Co-Evolution Trainer
Implements Algorithm 1 from the paper:

  For k = 1 to K:
    a. Freeze Blue(k-1), add to pool P
    b. Train Red via PPO against mixture of P
    c. Collect evasion samples → update diversity buffer B
    d. Retrain Blue(k) on D_seed ∪ B
    e. Evaluate Blue(k) zero-shot on held-out LLM outputs
    f. Log evasion_rate(k), F1_seen(k), F1_unseen(k)
"""

import json
import logging
import os
from typing import Dict, List, Optional

import torch

from cobra.blue_agent import BlueAgent
from cobra.config import COBRAConfig
from cobra.data import TextSample, make_dataloader
from cobra.diversity_buffer import DiversityBuffer
from cobra.red_agent_1 import RedAgent

logger = logging.getLogger(__name__)


class COBRATrainer:
    """
    Orchestrates the full Red-Blue co-evolutionary training loop.

    Args:
        config:          COBRAConfig instance
        seed_train:      Labeled training samples (seed dataset D_seed)
        seed_val:        Validation samples (seen LLMs)
        zero_shot_sets:  Dict mapping LLM name → test samples (unseen LLMs)
    """

    def __init__(
        self,
        config: COBRAConfig,
        seed_train: List[TextSample],
        seed_val: List[TextSample],
        zero_shot_sets: Dict[str, List[TextSample]],
    ):
        self.config        = config
        self.seed_train    = seed_train
        self.seed_val      = seed_val
        self.zero_shot_sets = zero_shot_sets

        os.makedirs(config.output_dir,    exist_ok=True)
        os.makedirs(config.checkpoint_dir, exist_ok=True)
        os.makedirs(config.log_dir,       exist_ok=True)

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"COBRA Trainer initialized | Device: {self.device}")

        # Agents
        self.blue   = BlueAgent(config, self.device)
        self.red    = RedAgent(config, self.device)
        self.buffer = DiversityBuffer(config)

        # Frozen checkpoint pool P  (list of frozen BlueAgent copies)
        self.blue_pool: List[BlueAgent] = []

        # Metrics log
        self.history: List[Dict] = []

    # ── Main entry point ─────────────────────────────────────────────────────

    def run(self) -> BlueAgent:
        """
        Execute the full co-evolution loop for K rounds.
        Returns the final Blue agent.
        """
        logger.info("=" * 60)
        logger.info("COBRA Co-Evolution Start")
        logger.info(f"  Rounds: {self.config.num_rounds}")
        logger.info(f"  Seed train: {len(self.seed_train)} samples")
        logger.info(f"  Zero-shot eval sets: {list(self.zero_shot_sets.keys())}")
        logger.info("=" * 60)
        print("🔥 Run Function is just started")
        # ── Round 0: warm-start Blue on seed data ────────────────────────────
        logger.info("\n[Round 0] Warm-start Blue on seed data...")

        self.blue.train_round(
            seed_samples=self.seed_train,
            buffer_samples=[],
            val_samples=self.seed_val,
            round_num=0,
        )
        print("🔥 Round 0 training complete")
        self.blue.save(os.path.join(self.config.checkpoint_dir, "blue_round_0"))
        
        print("🔥 Model is saved")

        round0_metrics = self._evaluate_all(round_num=0, evasion_rate=0.0,
                                             red_loss=0.0)
        print("🔥 Matrix calculated for round0")
        self.history.append(round0_metrics)
        self._log_metrics(round0_metrics)
        
        print("🔥 Round 0 Complete")

        # ── Co-evolution rounds 1 … K ────────────────────────────────────────
        for k in range(1, self.config.num_rounds + 1):
            print(f"🔥 Starting Round {k}")
            logger.info(f"\n{'='*60}")
            logger.info(f"ROUND {k} / {self.config.num_rounds}")
            logger.info(f"{'='*60}")

            # ── Step a: Freeze Blue(k-1), add to pool ────────────────────────
            frozen = self.blue.get_frozen_copy()
            self.blue_pool.append(frozen)
            logger.info(f"  Pool P now has {len(self.blue_pool)} frozen checkpoint(s)")

            # ── Step b: Train Red via PPO against pool P ─────────────────────
            logger.info("  Training Red agent (PPO)...")
            print("🔥 Starting RED training")
            ai_train = [s for s in self.seed_train if s.label == 1]
            # print(type(ai_train[0]), ai_train[0].text[:50])
            print(f"🔥 Number of AI samples for PPO training: {len(ai_train)}")
            red_stats = self.red.ppo_step(
                ai_samples=ai_train,
                blue_pool=self.blue_pool,
                round_num=k,
            )
            print("🔥 Ending RED training")
            # ── Step c: Collect evasion samples → update buffer ───────────────
            logger.info("  Collecting evasion samples...")
            print("🔥 collecting evasion samples")
            evasion_samples = self.red.collect_evasion_samples(
                ai_samples=ai_train,
                blue_agent=self.blue,
            )

            print(f"🔥 adding in buffer {len(evasion_samples)}")
            self.buffer.add(evasion_samples)
            self.buffer.save(self.config.buffer_path)
            
            logger.info(f"  Buffer size: {len(self.buffer)}")
            logger.info(f"  Buffer stats: {self.buffer.stats()}")
          
            # ── Step d: Retrain Blue(k) on D_seed ∪ B ────────────────────────
            logger.info("  Retraining Blue agent...")
            print("🔥 Starting BLUE training")
            blue_history = self.blue.train_round(
                seed_samples=self.seed_train,
                buffer_samples=self.buffer.get_all(),
                val_samples=self.seed_val,
                round_num=k,
            )
            self.blue.save(
                os.path.join(self.config.checkpoint_dir, f"blue_round_{k}")
            )
            print("🔥 Saving Blue Model and starting evaluation")

            # ── Step e+f: Evaluate + log ─────────────────────────────────────
            evasion_rate = red_stats["evasion_rate"]
            round_metrics = self._evaluate_all(
                round_num=k,
                evasion_rate=evasion_rate,
                red_loss=red_stats["loss"],
            )
            self.history.append(round_metrics)
            self._log_metrics(round_metrics)
            self._save_history()
            print(f"🔥 Round {k} Complete")

        logger.info("\n" + "=" * 60)
        logger.info("COBRA Co-Evolution Complete")
        logger.info(f"Final Blue saved to {self.config.checkpoint_dir}/blue_final")
        self.blue.save(os.path.join(self.config.checkpoint_dir, "blue_final"))
        return self.blue

    # ── Evaluation ────────────────────────────────────────────────────────────

    def _evaluate_all(
        self, round_num: int, evasion_rate: float, red_loss: float
    ) -> Dict:
        """
        Evaluate Blue on:
          - Validation set (seen LLMs) → F1_seen
          - Each zero-shot set (unseen LLMs) → F1_unseen per LLM
        """
        logger.info("  Evaluating Blue agent...")
        print("🔥 evaluating Blue agent started")
        # Seen LLMs
        seen_metrics = self.blue.evaluate_on_samples(self.seed_val)
        print("🔥 Seen matrics completed")
        # Zero-shot (unseen LLMs)
        zero_shot_metrics = {}
        for llm_name, test_samples in self.zero_shot_sets.items():
            test_samples = test_samples[:20]  # Limit for quick evaluation
            zs = self.blue.evaluate_on_samples(test_samples)
            zero_shot_metrics[llm_name] = zs
            print(f"🔥 Round 0 {llm_name} completed")
            logger.info(
                f"    Zero-shot [{llm_name}]: "
                f"F1={zs['f1']:.4f} | AUROC={zs['auroc']:.4f}"
            )
        print("🔥 Unseen metrics completed")
        # Average zero-shot F1
        avg_zs_f1 = (
            sum(m["f1"] for m in zero_shot_metrics.values()) / len(zero_shot_metrics)
            if zero_shot_metrics else 0.0
        )
        print("🔥 avg_zs_f1 completed")
        return {
            "round":            round_num,
            "evasion_rate":     evasion_rate,
            "red_loss":         red_loss,
            "val_f1":           seen_metrics["f1"],
            "val_auroc":        seen_metrics["auroc"],
            "val_accuracy":     seen_metrics["accuracy"],
            "zero_shot":        zero_shot_metrics,
            "avg_zero_shot_f1": avg_zs_f1,
            "buffer_size":      len(self.buffer),
        }

    # ── Logging & persistence ─────────────────────────────────────────────────

    def _log_metrics(self, m: Dict):
        logger.info(
            f"\n  ── Round {m['round']} Summary ──────────────────────────\n"
            f"  Evasion Rate:      {m['evasion_rate']:.3f}\n"
            f"  Val F1 (seen):     {m['val_f1']:.4f}\n"
            f"  Val AUROC:         {m['val_auroc']:.4f}\n"
            f"  Avg Zero-Shot F1:  {m['avg_zero_shot_f1']:.4f}\n"
            f"  Buffer size:       {m['buffer_size']}\n"
        )

    def _save_history(self):
        path = os.path.join(self.config.log_dir, "history.json")
        with open(path, "w") as f:
            json.dump(self.history, f, indent=2)
