# cobra/diversity_buffer.py
"""
Diversity Buffer: stores Red agent evasion samples with
cluster-based deduplication to ensure stylistic diversity.

Design:
  - Cluster incoming samples into C clusters (K-Means on sentence-BERT embeddings)
  - Keep at most N samples per cluster
  - Cap total buffer at max_size (FIFO eviction)
"""

import logging
import pickle
from collections import deque
from typing import List

import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize
from sentence_transformers import SentenceTransformer

from cobra.config import COBRAConfig
from cobra.data import TextSample

logger = logging.getLogger(__name__)


class DiversityBuffer:
    """
    Maintains a stylistically diverse set of Red agent evasion samples.

    Clustering ensures that when Red finds many similar perturbations
    (e.g., all lexical substitutions), only a representative subset
    is kept. This forces Blue to train on truly varied evasion styles.
    """

    def __init__(self, config: COBRAConfig):
        self.config   = config
        self.max_size = config.buffer_max_size
        self.n_clusters = config.buffer_clusters
        self.max_per_cluster = config.buffer_samples_per_cluster

        self._buffer: deque = deque(maxlen=self.max_size)
        self.sbert = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")

    # ── Public API ────────────────────────────────────────────────────────────

    def add(self, new_samples: List[TextSample]) -> int:
        """
        Add new evasion samples to buffer with cluster-based filtering.
        Returns number of samples actually added.
        """
        if not new_samples:
            return 0

        if len(new_samples) < self.n_clusters:
            # Too few samples to cluster — add all
            for s in new_samples:
                self._buffer.append(s)
            logger.info(f"Buffer: added {len(new_samples)} samples (no clustering, buffer too small)")
            return len(new_samples)

        # Embed new samples
        texts = [s.text for s in new_samples]
        embeddings = self._embed(texts)                # (N, D)

        # Cluster
        n_clusters = min(self.n_clusters, len(new_samples))
        kmeans = KMeans(n_clusters=n_clusters, random_state=self.config.seed,
                        n_init=10)
        cluster_labels = kmeans.fit_predict(embeddings) # (N,)

        # Sample up to max_per_cluster from each cluster
        selected = []
        for c in range(n_clusters):
            cluster_indices = np.where(cluster_labels == c)[0]
            # Sort by distance to centroid (keep most representative)
            centroid = kmeans.cluster_centers_[c]
            dists    = np.linalg.norm(
                embeddings[cluster_indices] - centroid, axis=1
            )
            sorted_idx = cluster_indices[np.argsort(dists)]
            keep       = sorted_idx[: self.max_per_cluster]
            selected.extend([new_samples[i] for i in keep])

        added = 0
        for s in selected:
            self._buffer.append(s)
            added += 1

        logger.info(
            f"Buffer: added {added}/{len(new_samples)} samples across "
            f"{n_clusters} clusters | Total: {len(self._buffer)}"
        )
        return added

    def get_all(self) -> List[TextSample]:
        """Return all samples currently in the buffer."""
        return list(self._buffer)

    def __len__(self) -> int:
        return len(self._buffer)

    def is_empty(self) -> bool:
        return len(self._buffer) == 0

    # ── Persistence ───────────────────────────────────────────────────────────

    def save(self, path: str):
        with open(path, "wb") as f:
            pickle.dump(list(self._buffer), f)
        logger.info(f"Buffer saved: {len(self._buffer)} samples → {path}")

    def load(self, path: str):
        with open(path, "rb") as f:
            samples = pickle.load(f)
        self._buffer = deque(samples, maxlen=self.max_size)
        logger.info(f"Buffer loaded: {len(self._buffer)} samples from {path}")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _embed(self, texts: List[str]) -> np.ndarray:
        embeddings = self.sbert.encode(texts, show_progress_bar=False,
                                        batch_size=64)
        return normalize(embeddings)                   # L2-normalize for cosine K-Means

    def stats(self) -> dict:
        """Return buffer statistics."""
        if not self._buffer:
            return {"size": 0, "domains": {}, "source_llms": {}}

        domains   = {}
        llms      = {}
        for s in self._buffer:
            domains[s.domain]         = domains.get(s.domain, 0) + 1
            llms[s.source_llm]        = llms.get(s.source_llm, 0) + 1

        return {
            "size":        len(self._buffer),
            "domains":     domains,
            "source_llms": llms,
        }
