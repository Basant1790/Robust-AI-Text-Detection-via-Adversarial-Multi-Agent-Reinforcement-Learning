#!/usr/bin/env python3
# main.py
import argparse
import logging
import os
import random
import json
import numpy as np
import torch
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

from cobra.config import COBRAConfig
from cobra.data import load_hc3, load_raid, train_val_test_split
from cobra.trainer import COBRATrainer
from cobra.blue_agent import BlueAgent
from cobra.evaluate import COBRAEvaluator
import logging

# 🔥 suppress noisy logs
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("transformers").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.basicConfig(format="%(asctime)s | %(levelname)s | %(name)s | %(message)s", level=logging.INFO)
logger = logging.getLogger("COBRA")

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def load_all_data(data_dir: str, config: COBRAConfig):
    """Loads HC3 and RAID; strictly skips M4."""
    logger.info("Loading datasets...")
    all_samples = []

    # 1. HC3
    hc3_path = os.path.join(data_dir, "hc3", "all.jsonl")
    if os.path.exists(hc3_path):
        hc3 = load_hc3(hc3_path)
        logger.info(f"  HC3 loaded: {len(hc3)} samples")
        all_samples.extend(hc3)

    # 2. RAID
    raid_dir = os.path.join(data_dir, "raid")
    if os.path.exists(raid_dir) and os.path.exists(os.path.join(raid_dir, "train.csv")):
        raid = load_raid(raid_dir, split="train")
        logger.info(f"  RAID loaded: {len(raid)} samples")
        all_samples.extend(raid)

    if not all_samples:
        raise ValueError("No datasets found! Ensure HC3 and RAID are in the data/ folder.")


    ai_samples = []
    human_samples = []

    for s in all_samples:
        if s.label == 0:
            human_samples.append(s)
        else:
            ai_samples.append(s)
    
    random.shuffle(ai_samples)
    random.shuffle(human_samples)
    print(f"AI: {len(ai_samples)}, Human: {len(human_samples)}")
    n = min(10, len(ai_samples), len(human_samples))
    balanced_samples = ai_samples[:n] + human_samples[:n]
    all_samples = balanced_samples
    # --- SUBSAMPLING LOGIC START ---
    # Limit to 50,000 samples for the first experiment to prevent memory crashes
    logger.info(f"Total samples collected: {len(all_samples)}. Subsampling to 50,000...")
    random.seed(config.seed) 
    random.shuffle(all_samples)
    # print("Before subsample:", len(all_samples))
    # all_samples = all_samples[:10000] 
    # print("After subsample:", len(all_samples))
    # --- SUBSAMPLING LOGIC END ---

    # Split into train / val / seen-test
    train, val, seen_test = train_val_test_split(all_samples, train_ratio=0.8, val_ratio=0.1, seed=config.seed)
    logger.info(f"  Split -> Train: {len(train)} | Val: {len(val)} | Test: {len(seen_test)}")

    # Zero-shot evaluation sets remain empty for now
    # zero_shot_sets = {"seen_test": seen_test}# first we made this empty but then we added seen_test here to have some data for zero-shot evaluation. We can later add more zero-shot sets if needed. 
    # return train, val, seen_test, zero_shot_sets
    random.seed(config.seed)
    random.shuffle(seen_test)
    mid = len(seen_test) // 2
    eval_test = seen_test[:mid]
    zero_shot_sets = {"proxy_zeroshot": seen_test[mid:]}

    return train, val, eval_test, zero_shot_sets

def parse_args():
    p = argparse.ArgumentParser(description="COBRA Training & Evaluation")
    p.add_argument("--mode", choices=["train", "eval"], default="train")
    p.add_argument("--data_dir", default="./data")
    p.add_argument("--output_dir", default="./cobra_outputs")
    p.add_argument("--checkpoint", default=None)
    p.add_argument("--num_rounds", type=int, default=10)
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()

def main():
    args = parse_args()
    set_seed(args.seed)

    config = COBRAConfig(
        num_rounds=args.num_rounds,
        seed=args.seed,
        output_dir=args.output_dir,
        checkpoint_dir=os.path.join(args.output_dir, "checkpoints"),
        log_dir=os.path.join(args.output_dir, "logs"),
        buffer_path=os.path.join(args.output_dir, "diversity_buffer.pkl"),
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")

    if args.mode == "train":
        train, val, seen_test, zero_shot_sets = load_all_data(args.data_dir, config)
        trainer = COBRATrainer(config, train, val, zero_shot_sets)
        blue = trainer.run()
        evaluator = COBRAEvaluator(config, device)
        report = evaluator.full_report(blue, seen_test, zero_shot_sets, 
                                       save_path=os.path.join(args.output_dir, "logs", "final_report.json"))
        evaluator.print_table(report)

if __name__ == "__main__":
    main()