# cobra/evaluate.py
"""
Evaluation utilities:
  - Full benchmark runner (COBRA vs. baselines)
  - Zero-shot generalization report
  - Ablation study runner
  - Metrics: F1, AUROC, Accuracy, Δ-Generalization Gap
"""

import json
import logging
import os
from typing import Dict, List, Optional

import numpy as np
import torch
from sklearn.metrics import (
    f1_score, roc_auc_score, accuracy_score,
    confusion_matrix, classification_report
)
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    pipeline,
)

from cobra.blue_agent import BlueAgent
from cobra.config import COBRAConfig
from cobra.data import TextSample, make_dataloader

logger = logging.getLogger(__name__)


# ── Core metric function ──────────────────────────────────────────────────────

def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray,
) -> Dict[str, float]:
    """Compute all detection metrics."""
    y_prob = np.nan_to_num(y_prob, nan=0.5)
    return {
        "f1_macro":   f1_score(y_true, y_pred, average="macro"),
        "f1_binary":  f1_score(y_true, y_pred, average="binary"),
        "auroc":      roc_auc_score(y_true, y_prob),
        "accuracy":   accuracy_score(y_true, y_pred),
        "precision":  float(confusion_matrix(y_true, y_pred)[1, 1] /
                            (confusion_matrix(y_true, y_pred)[1, 1] +
                             confusion_matrix(y_true, y_pred)[0, 1] + 1e-8)),
        "recall":     float(confusion_matrix(y_true, y_pred)[1, 1] /
                            (confusion_matrix(y_true, y_pred)[1, 1] +
                             confusion_matrix(y_true, y_pred)[1, 0] + 1e-8)),
        "fpr":        float(confusion_matrix(y_true, y_pred)[0, 1] /
                            (confusion_matrix(y_true, y_pred)[0, 1] +
                             confusion_matrix(y_true, y_pred)[0, 0] + 1e-8)),
    }


# ── COBRA evaluator ───────────────────────────────────────────────────────────

class COBRAEvaluator:
    """
    Runs the full evaluation suite:
      1. Seen-LLM test set
      2. Zero-shot unseen-LLM test sets
      3. Δ-Generalization Gap
      4. Comparison vs. baselines
    """

    def __init__(self, config: COBRAConfig, device: torch.device):
        self.config = config
        self.device = device

    def full_report(
        self,
        blue: BlueAgent,
        seen_test: List[TextSample],
        zero_shot_sets: Dict[str, List[TextSample]],
        baselines: Optional[Dict[str, "BaselineDetector"]] = None,
        save_path: Optional[str] = None,
    ) -> Dict:
        """
        Generate complete evaluation report.
        """
        report = {}

        # ── COBRA on seen LLMs ────────────────────────────────────────────
        logger.info("Evaluating COBRA on seen LLMs...")
        seen_metrics = self._eval_blue(blue, seen_test)
        report["cobra_seen"] = seen_metrics

        # ── COBRA zero-shot ────────────────────────────────────────────────
        logger.info("Evaluating COBRA zero-shot on unseen LLMs...")
        zs_results = {}
        for llm, samples in zero_shot_sets.items():
            m = self._eval_blue(blue, samples)
            zs_results[llm] = m
            logger.info(f"  {llm}: F1={m['f1_macro']:.4f} | AUROC={m['auroc']:.4f}")
        report["cobra_zero_shot"] = zs_results

        # ── Δ-Generalization Gap ───────────────────────────────────────────
        avg_zs_f1 = np.mean([m["f1_macro"] for m in zs_results.values()])
        report["delta_generalization_gap"] = seen_metrics["f1_macro"] - avg_zs_f1
        report["avg_zero_shot_f1"]         = float(avg_zs_f1)

        logger.info(
            f"  Δ-Generalization Gap: "
            f"{report['delta_generalization_gap']:.4f} "
            f"(lower = better generalization)"
        )

        # ── Baselines ──────────────────────────────────────────────────────
        if baselines:
            report["baselines"] = {}
            for name, detector in baselines.items():
                logger.info(f"  Evaluating baseline: {name}")
                b_seen = detector.evaluate(seen_test)
                b_zs   = {llm: detector.evaluate(s)
                           for llm, s in zero_shot_sets.items()}
                b_avg_zs = np.mean([m["f1_macro"] for m in b_zs.values()])
                report["baselines"][name] = {
                    "seen":       b_seen,
                    "zero_shot":  b_zs,
                    "avg_zs_f1":  float(b_avg_zs),
                    "delta_gap":  b_seen["f1_macro"] - b_avg_zs,
                }

        if save_path:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, "w") as f:
                json.dump(report, f, indent=2)
            logger.info(f"Report saved to {save_path}")

        return report

    def print_table(self, report: Dict):
        """Print a formatted comparison table to stdout."""
        print("\n" + "=" * 70)
        print(f"{'Method':<25} {'Seen F1':>10} {'ZS F1':>10} {'AUROC':>10} {'Δ Gap':>10}")
        print("-" * 70)

        cobra_seen = report["cobra_seen"]["f1_macro"]
        cobra_zs   = report["avg_zero_shot_f1"]
        cobra_auroc = report["cobra_seen"]["auroc"]
        cobra_gap  = report["delta_generalization_gap"]
        print(f"{'COBRA (ours)':<25} {cobra_seen:>10.4f} {cobra_zs:>10.4f} "
              f"{cobra_auroc:>10.4f} {cobra_gap:>10.4f}")

        for name, m in report.get("baselines", {}).items():
            print(
                f"{name:<25} "
                f"{m['seen']['f1_macro']:>10.4f} "
                f"{m['avg_zs_f1']:>10.4f} "
                f"{m['seen']['auroc']:>10.4f} "
                f"{m['delta_gap']:>10.4f}"
            )
        print("=" * 70 + "\n")

    def _eval_blue(
        self, blue: BlueAgent, samples: List[TextSample]
    ) -> Dict[str, float]:
        texts  = [s.text  for s in samples]
        labels = np.array([s.label for s in samples])
        probs  = blue.predict_proba(texts)
        preds  = (probs >= 0.5).astype(int)
        return compute_metrics(labels, preds, probs)


# ── Ablation runner ───────────────────────────────────────────────────────────

class AblationRunner:
    """
    Run ablation variants:
      COBRA-NB  : No diversity buffer
      COBRA-NS  : No semantic constraint
      COBRA-NP  : No frozen pool (Red vs. latest Blue only)
      COBRA-SR  : Single round
      Blue-Only : No Red agent
    """

    VARIANTS = {
        "COBRA-NB": {"use_buffer": False,  "use_semantic_constraint": True,
                     "use_pool": True,  "num_rounds": 10},
        "COBRA-NS": {"use_buffer": True,   "use_semantic_constraint": False,
                     "use_pool": True,  "num_rounds": 10},
        "COBRA-NP": {"use_buffer": True,   "use_semantic_constraint": True,
                     "use_pool": False, "num_rounds": 10},
        "COBRA-SR": {"use_buffer": True,   "use_semantic_constraint": True,
                     "use_pool": True,  "num_rounds": 1},
        "Blue-Only":{"use_buffer": False,  "use_semantic_constraint": True,
                     "use_pool": False, "num_rounds": 0},
    }

    def run_all(
        self,
        base_config: COBRAConfig,
        seed_train: List[TextSample],
        seed_val: List[TextSample],
        zero_shot_sets: Dict[str, List[TextSample]],
    ) -> Dict:
        from cobra.trainer import COBRATrainer

        results = {}
        for variant_name, overrides in self.VARIANTS.items():
            logger.info(f"\nRunning ablation: {variant_name}")
            cfg = COBRAConfig(
                **{**base_config.__dict__,
                   "num_rounds": overrides["num_rounds"],
                   "output_dir": f"{base_config.output_dir}/ablation_{variant_name}",
                   "checkpoint_dir": f"{base_config.checkpoint_dir}/ablation_{variant_name}",
                   "red_semantic_threshold": (
                       0.0 if not overrides["use_semantic_constraint"]
                       else base_config.red_semantic_threshold
                   ),
                }
            )
            trainer = COBRATrainer(cfg, seed_train, seed_val, zero_shot_sets)

            # Disable buffer / pool based on variant
            if not overrides["use_buffer"]:
                trainer.buffer._buffer.clear()

            blue = trainer.run()

            evaluator = COBRAEvaluator(cfg, trainer.device)
            report = evaluator.full_report(blue, seed_val, zero_shot_sets)
            results[variant_name] = {
                "avg_zero_shot_f1":        report["avg_zero_shot_f1"],
                "seen_f1":                 report["cobra_seen"]["f1_macro"],
                "delta_generalization_gap": report["delta_generalization_gap"],
            }

        return results


# ── Baseline detectors ────────────────────────────────────────────────────────

class BaselineDetector:
    """Base class for baseline detectors."""
    def evaluate(self, samples: List[TextSample]) -> Dict[str, float]:
        raise NotImplementedError


class RoBERTaBaseline(BaselineDetector):
    """Fine-tuned RoBERTa-base/large detector (static, no co-evolution)."""

    def __init__(self, model_name: str, device: torch.device):
        self.device    = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model     = AutoModelForSequenceClassification.from_pretrained(
            model_name, num_labels=2
        ).to(device)

    def evaluate(self, samples: List[TextSample]) -> Dict[str, float]:
        texts  = [s.text  for s in samples]
        labels = np.array([s.label for s in samples])
        all_probs = []

        self.model.eval()
        with torch.no_grad():
            for i in range(0, len(texts), 32):
                batch = texts[i:i+32]
                enc = self.tokenizer(batch, max_length=512, padding=True,
                                     truncation=True, return_tensors="pt").to(self.device)
                logits = self.model(**enc).logits
                probs  = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()
                all_probs.extend(probs)

        probs = np.array(all_probs)
        preds = (probs >= 0.5).astype(int)
        return compute_metrics(labels, preds, probs)


class DetectGPTBaseline(BaselineDetector):
    """
    DetectGPT: perturbation-based detector.
    Requires access to a scoring LLM (e.g., GPT-2 for log-prob scoring).
    Uses T5 for mask-filling perturbations.
    """

    def __init__(self, scoring_model: str = "gpt2",
                 perturbation_model: str = "t5-large",
                 n_perturbations: int = 100, device: torch.device = None):
        self.device = device or torch.device("cpu")
        self.n_perturbations = n_perturbations

        from transformers import GPT2LMHeadModel, GPT2Tokenizer
        self.score_tokenizer = GPT2Tokenizer.from_pretrained(scoring_model)
        self.score_model     = GPT2LMHeadModel.from_pretrained(
            scoring_model).to(self.device)

        self.perturb_pipe = pipeline(
            "text2text-generation", model=perturbation_model, device=self.device
        )

    def _log_prob(self, text: str) -> float:
        tokens = self.score_tokenizer(text, return_tensors="pt",
                                       max_length=512, truncation=True).to(self.device)
        with torch.no_grad():
            loss = self.score_model(**tokens, labels=tokens["input_ids"]).loss
        return -loss.item()

    def _perturb(self, text: str) -> List[str]:
        prompt = f"paraphrase: {text}"
        results = self.perturb_pipe(
            [prompt] * self.n_perturbations,
            max_new_tokens=128, do_sample=True, temperature=0.8
        )
        return [r["generated_text"] for r in results]

    def detect(self, text: str) -> float:
        """Return score > 0 if AI-generated (higher = more confident)."""
        orig_score   = self._log_prob(text)
        perturbed    = self._perturb(text)
        perturb_mean = np.mean([self._log_prob(p) for p in perturbed])
        return orig_score - perturb_mean

    def evaluate(self, samples: List[TextSample]) -> Dict[str, float]:
        scores = np.array([self.detect(s.text) for s in samples])
        labels = np.array([s.label for s in samples])
        # Normalize to [0,1] probability
        probs = (scores - scores.min()) / (scores.max() - scores.min() + 1e-8)
        preds = (probs >= 0.5).astype(int)
        return compute_metrics(labels, preds, probs)
