#!/usr/bin/env python3
# cobra/datadown.py
"""
COBRA Dataset Downloader
========================
Downloads and converts all required datasets from HuggingFace into the
exact directory / file format expected by cobra/data.py:

  data/
  ├── hc3/
  │   └── all.jsonl          ← load_hc3()  expects this path
  ├── raid/
  │   └── train.csv          ← load_raid() expects split="train" → train.csv
  ├── m4/
  │   └── *.jsonl            ← load_m4()   scans all .jsonl files in dir
  └── mage/
      └── mage.jsonl         ← load_mage() expects this path

Usage:
    python download_datasets.py                      # saves to ./data
    python download_datasets.py --data_dir /my/path  # custom root
    python download_datasets.py --skip hc3 raid      # skip specific datasets
"""

import argparse
import csv
import json
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("download")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def require(pkg: str):
    """Abort with a helpful message if a package is missing."""
    try:
        __import__(pkg)
    except ImportError:
        logger.error(f"Package '{pkg}' not found. Run:  pip install {pkg}")
        sys.exit(1)


def save_jsonl(records: list, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    logger.info(f"  Saved {len(records):,} records → {path}")


def save_csv(rows: list, fieldnames: list, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"  Saved {len(rows):,} rows → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# HC3  (human_answers / chatgpt_answers  per question)
# HuggingFace: Hello-SimpleAI/HC3
# ─────────────────────────────────────────────────────────────────────────────

def download_hc3(data_dir: str):
    """
    Expected output: data/hc3/all.jsonl
    Each line: {"human_answers": [...], "chatgpt_answers": [...], "source": "..."}
    """
    logger.info("── HC3 ──────────────────────────────────────────────────────")
    from datasets import load_dataset

    # 'all' config merges all domains (finance, medicine, open_qa, reddit, wiki)
    ds = load_dataset("Hello-SimpleAI/HC3", "all", trust_remote_code=True)

    records = []
    for split_name in ds.keys():
        for row in ds[split_name]:
            records.append({
                "human_answers":   row.get("human_answers", []),
                "chatgpt_answers": row.get("chatgpt_answers", []),
                "source":          row.get("source", "general"),
            })

    out_path = os.path.join(data_dir, "hc3", "all.jsonl")
    save_jsonl(records, out_path)
    logger.info(f"  HC3 done: {len(records):,} QA items")


# ─────────────────────────────────────────────────────────────────────────────
# RAID  (multi-LLM, multi-domain — largest dataset)
# HuggingFace: liamdugan/raid
# ─────────────────────────────────────────────────────────────────────────────

def download_raid(data_dir: str):
    """
    Expected output: data/raid/train.csv
    Columns: id, generation, model, domain
    """
    logger.info("── RAID ─────────────────────────────────────────────────────")
    from datasets import load_dataset

    ds = load_dataset("liamdugan/raid", trust_remote_code=True)

    fieldnames = ["id", "generation", "model", "domain"]
    rows = []

    # RAID provides a 'train' split; use it all
    split = ds.get("train") or ds[list(ds.keys())[0]]
    for i, row in enumerate(split):
        rows.append({
            "id":         row.get("id", str(i)),
            "generation": row.get("generation", row.get("text", "")),
            "model":      row.get("model", "unknown"),
            "domain":     row.get("domain", "general"),
        })

    out_path = os.path.join(data_dir, "raid", "train.csv")
    save_csv(rows, fieldnames, out_path)
    logger.info(f"  RAID done: {len(rows):,} samples")


# ─────────────────────────────────────────────────────────────────────────────
# M4  (multilingual, multi-generator)
# HuggingFace: NicolaiSivesind/ChatGPT-Research-Abstracts  (English subset)
#              or  mbzuai-nlp/M4  if available
# ─────────────────────────────────────────────────────────────────────────────

def download_m4(data_dir: str):
    """
    Expected output: data/m4/<domain>.jsonl
    Each line: {"text": "...", "label": 0|1, "model": "...", "domain": "..."}
    """
    logger.info("── M4 ───────────────────────────────────────────────────────")
    from datasets import load_dataset

    # Primary: official M4 dataset
    # Fallback: a well-known English academic subset
    try:
        ds = load_dataset("mbzuai-nlp/M4", trust_remote_code=True)
        logger.info("  Using mbzuai-nlp/M4")
        _save_m4_from_hf(ds, data_dir)
    except Exception as e:
        logger.warning(f"  mbzuai-nlp/M4 unavailable ({e}), trying fallback…")
        try:
            # Fallback: Wikipedia + arXiv text reuse dataset (MGTBench)
            ds = load_dataset("aadityaubhat/GPT-wiki-intro", trust_remote_code=True)
            logger.info("  Using aadityaubhat/GPT-wiki-intro as M4 fallback")
            _save_m4_fallback_wiki(ds, data_dir)
        except Exception as e2:
            logger.error(f"  M4 fallback also failed: {e2}")
            logger.error("  Skipping M4. Add data manually to data/m4/*.jsonl")


def _save_m4_from_hf(ds, data_dir: str):
    """Save official M4 splits."""
    by_domain: dict = {}
    for split_name in ds.keys():
        for row in ds[split_name]:
            domain = row.get("domain", row.get("source", "general"))
            rec = {
                "text":   row.get("text", row.get("human_text", "")),
                "label":  int(row.get("label", 0)),
                "model":  row.get("model", "unknown"),
                "domain": domain,
            }
            by_domain.setdefault(domain, []).append(rec)

    for domain, records in by_domain.items():
        safe_name = domain.replace("/", "_").replace(" ", "_")
        out_path = os.path.join(data_dir, "m4", f"{safe_name}.jsonl")
        save_jsonl(records, out_path)
    logger.info(f"  M4 done: {sum(len(v) for v in by_domain.values()):,} samples "
                f"across {len(by_domain)} domains")


def _save_m4_fallback_wiki(ds, data_dir: str):
    """Convert GPT-wiki-intro into M4-compatible format."""
    records = []
    split = ds.get("train") or ds[list(ds.keys())[0]]
    for row in split:
        # Human intro
        if row.get("wiki_intro", "").strip():
            records.append({
                "text":   row["wiki_intro"].strip(),
                "label":  0,
                "model":  "human",
                "domain": "wikipedia",
            })
        # GPT-3 intro
        if row.get("generated_intro", "").strip():
            records.append({
                "text":   row["generated_intro"].strip(),
                "label":  1,
                "model":  "gpt-3",
                "domain": "wikipedia",
            })

    out_path = os.path.join(data_dir, "m4", "wikipedia.jsonl")
    save_jsonl(records, out_path)
    logger.info(f"  M4 fallback done: {len(records):,} samples")


# ─────────────────────────────────────────────────────────────────────────────
# MAGE  (zero-shot eval — diverse unseen LLMs)
# HuggingFace: yaful/MAGE  or  tum-nlp/MAGE
# ─────────────────────────────────────────────────────────────────────────────

def download_mage(data_dir: str):
    """
    Expected output: data/mage/mage.jsonl
    Each line: {"text": "...", "label": 0|1, "model": "...", "domain": "..."}
    """
    logger.info("── MAGE ─────────────────────────────────────────────────────")
    from datasets import load_dataset

    candidates = ["yaful/MAGE", "tum-nlp/MAGE", "Hello-SimpleAI/mage"]
    ds = None
    for repo in candidates:
        try:
            ds = load_dataset(repo, trust_remote_code=True)
            logger.info(f"  Using {repo}")
            break
        except Exception as e:
            logger.warning(f"  {repo} unavailable: {e}")

    if ds is None:
        # Last-resort: use a subset of HC3 with extra LLMs (Claude, Bard)
        logger.warning("  MAGE not found on HuggingFace. "
                       "Generating synthetic MAGE from HC3 subset as placeholder.")
        _save_mage_placeholder(data_dir)
        return

    records = []
    for split_name in ds.keys():
        for row in ds[split_name]:
            records.append({
                "text":   row.get("text", ""),
                "label":  int(row.get("label", row.get("label_int", 0))),
                "model":  row.get("model", row.get("generator", "unknown")),
                "domain": row.get("domain", row.get("source", "general")),
            })

    out_path = os.path.join(data_dir, "mage", "mage.jsonl")
    save_jsonl(records, out_path)
    logger.info(f"  MAGE done: {len(records):,} samples")


def _save_mage_placeholder(data_dir: str):
    """
    Fallback: download LLM-generated text from an alternative source
    (LLM-generated news, academic text) to stand in for MAGE zero-shot eval.
    Uses: Hello-SimpleAI/HC3-Chinese subset (English fallback) or
          theblackcat102/human-written-paragraphs for human side +
          a small GPT-2 generated set for AI side.
    """
    from datasets import load_dataset

    records = []
    try:
        # Human side: Wikipedia introductions
        wiki = load_dataset("wikimedia/wikipedia", "20231101.en",
                            split="train[:3000]", trust_remote_code=True)
        for row in wiki:
            text = (row.get("text") or "").strip()
            if len(text) > 100:
                records.append({
                    "text":   text[:15000],
                    "label":  0,
                    "model":  "human",
                    "domain": "wikipedia",
                })
            if len(records) >= 15000:
                break
    except Exception as e:
        logger.warning(f"  Wikipedia fallback failed: {e}")

    try:
        # AI side: use HC3 chatgpt answers as proxy for unseen LLMs
        hc3 = load_dataset("Hello-SimpleAI/HC3", "all",
                           split="train[:5000]", trust_remote_code=True)
        llm_tags = ["gpt-4-proxy", "gemini-proxy", "mistral-proxy", "command-r-proxy"]
        for i, row in enumerate(hc3):
            for ans in row.get("chatgpt_answers", [])[:1]:
                if ans.strip():
                    records.append({
                        "text":   ans.strip(),
                        "label":  1,
                        "model":  llm_tags[i % len(llm_tags)],
                        "domain": row.get("source", "general"),
                    })
    except Exception as e:
        logger.warning(f"  HC3 fallback for MAGE failed: {e}")

    out_path = os.path.join(data_dir, "mage", "mage.jsonl")
    save_jsonl(records, out_path)
    logger.warning(
        "  MAGE placeholder saved. For real zero-shot eval, replace with "
        "the official MAGE dataset when available."
    )


# ─────────────────────────────────────────────────────────────────────────────
# Directory scaffold
# ─────────────────────────────────────────────────────────────────────────────

def create_directories(data_dir: str):
    """Create the full expected directory tree under data_dir."""
    dirs = ["hc3", "raid", "m4", "mage"]
    for d in dirs:
        path = os.path.join(data_dir, d)
        os.makedirs(path, exist_ok=True)
        logger.info(f"  Directory ready: {path}")


def verify_structure(data_dir: str):
    """Check that all files expected by data.py are present."""
    expected = {
        "HC3":  os.path.join(data_dir, "hc3", "all.jsonl"),
        "RAID": os.path.join(data_dir, "raid", "train.csv"),
        "M4":   os.path.join(data_dir, "m4"),    # directory with ≥1 .jsonl
        "MAGE": os.path.join(data_dir, "mage", "mage.jsonl"),
    }

    print("\n" + "=" * 55)
    print("  Dataset verification")
    print("=" * 55)
    all_ok = True
    for name, path in expected.items():
        if name == "M4":
            files = [f for f in os.listdir(path) if f.endswith(".jsonl")] \
                    if os.path.isdir(path) else []
            status = f"✓  {len(files)} .jsonl file(s)" if files else "✗  NO .jsonl files"
            ok = bool(files)
        else:
            ok = os.path.isfile(path)
            status = "✓  found" if ok else "✗  MISSING"
        print(f"  {name:<6} {status}")
        if not ok:
            all_ok = False

    print("=" * 55)
    if all_ok:
        print("  All datasets ready — you can now run COBRA training!\n")
    else:
        print("  Some datasets are missing. Check logs above for errors.\n")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

DATASET_FUNCS = {
    "hc3":  download_hc3,
    "raid": download_raid,
    "m4":   download_m4,
    "mage": download_mage,
}


def parse_args():
    p = argparse.ArgumentParser(
        description="Download COBRA datasets from HuggingFace"
    )
    p.add_argument(
        "--data_dir", default="./data",
        help="Root data directory (default: ./data)"
    )
    p.add_argument(
        "--only", nargs="+", choices=list(DATASET_FUNCS.keys()),
        help="Download only these datasets"
    )
    p.add_argument(
        "--skip", nargs="+", choices=list(DATASET_FUNCS.keys()),
        default=[],
        help="Skip these datasets"
    )
    p.add_argument(
        "--verify_only", action="store_true",
        help="Only verify directory structure, no downloading"
    )
    return p.parse_args()


def main():
    args = parse_args()
    data_dir = os.path.abspath(args.data_dir)

    # Check dependencies
    require("datasets")
    require("huggingface_hub")

    logger.info(f"Data directory: {data_dir}")
    create_directories(data_dir)

    if args.verify_only:
        verify_structure(data_dir)
        return

    # Decide which datasets to download
    to_download = list(DATASET_FUNCS.keys())
    if args.only:
        to_download = [d for d in to_download if d in args.only]
    to_download = [d for d in to_download if d not in (args.skip or [])]

    logger.info(f"Downloading: {to_download}")

    for name in to_download:
        try:
            DATASET_FUNCS[name](data_dir)
        except Exception as e:
            logger.error(f"Failed to download {name.upper()}: {e}")
            logger.error("  Skipping — fix and re-run with --only " + name)

    verify_structure(data_dir)

    print("Next steps:")
    print(f"  python main.py --mode train --data_dir {data_dir} --output_dir ./cobra_outputs")


if __name__ == "__main__":
    main()