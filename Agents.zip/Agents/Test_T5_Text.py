# test_t5_paraphrase.py

from transformers import T5ForConditionalGeneration, T5Tokenizer
import torch

def load_model(model_name="t5-base"):
    tokenizer = T5Tokenizer.from_pretrained(model_name)
    model = T5ForConditionalGeneration.from_pretrained(model_name)
    return tokenizer, model

def paraphrase(text, tokenizer, model, device="cpu"):
    model = model.to(device)
    model.eval()

    # T5 expects task prefix
    input_text = "paraphrase: " + text + " </s>"

    encoding = tokenizer(
        input_text,
        padding=True,
        truncation=True,
        max_length=128,
        return_tensors="pt"
    ).to(device)

    with torch.no_grad():
        outputs = model.generate(
            **encoding,
            max_length=128,
            num_beams=5,                 # more stable than sampling
            num_return_sequences=3,
            repetition_penalty=1.2,
            no_repeat_ngram_size=2,
            early_stopping=True
        )

    decoded = [tokenizer.decode(ids, skip_special_tokens=True) for ids in outputs]
    return decoded

if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tokenizer, model = load_model("t5-base")

    text = "Artificial intelligence is transforming the way we interact with technology."

    results = paraphrase(text, tokenizer, model, device)

    print("\nOriginal:")
    print(text)

    print("\nParaphrases:")
    for i, r in enumerate(results):
        print(f"{i+1}. {r}")