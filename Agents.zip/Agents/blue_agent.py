# cobra/blue_agent.py
"""
Blue Agent: DeBERTa-v3-large binary classifier.
Detects AI-generated text. Trained each co-evolution round
against seed data + diversity buffer.
"""

import os
import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    get_cosine_schedule_with_warmup,
)
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score
from tqdm import tqdm

from cobra.config import COBRAConfig
from cobra.data import TextSample, make_dataloader, balance_dataset

logger = logging.getLogger(__name__)


class BlueAgent:
    """
    DeBERTa-v3-large binary classifier for AI text detection.

    Trained via standard cross-entropy on a mix of:
      - D_seed:  original human vs. AI dataset
      - B_k:     diversity buffer (Red agent evasion samples)
    """

    def __init__(self, config: COBRAConfig, device: torch.device):
        self.config = config
        self.device = device

        logger.info(f"Loading Blue agent: {config.blue_model_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(
            config.blue_model_name,
            use_fast=False # from gemini, as DeBERTa's fast tokenizer has issues with some inputs

        )
        self.model = AutoModelForSequenceClassification.from_pretrained(
            config.blue_model_name, num_labels=2, ignore_mismatched_sizes=True
        ).to(device)

    # ── Training ──────────────────────────────────────────────────────────────

    def train_round(
        self,
        seed_samples: List[TextSample],
        buffer_samples: List[TextSample],
        val_samples: List[TextSample],
        round_num: int,
    ) -> Dict[str, float]:
        """
        Train Blue for one co-evolution round.
        Combines seed data with diversity buffer.
        """
        combined = balance_dataset(seed_samples + buffer_samples, self.config.seed)
        logger.info(
            f"[Round {round_num}] Blue training: "
            f"{len(seed_samples)} seed + {len(buffer_samples)} buffer "
            f"= {len(combined)} total samples"
        )

        train_loader = make_dataloader(
            combined, self.tokenizer,
            self.config.blue_batch_size, self.config.blue_max_seq_len
        )
        val_loader = make_dataloader(
            val_samples, self.tokenizer,
            self.config.eval_batch_size, self.config.blue_max_seq_len,
            shuffle=False
        )

        optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.blue_lr,
            weight_decay=self.config.blue_weight_decay,
            eps=1e-6 #gemini
        )
        total_steps   = len(train_loader) * self.config.blue_epochs_per_round
        warmup_steps  = int(total_steps * self.config.blue_warmup_ratio)
        scheduler     = get_cosine_schedule_with_warmup(
            optimizer, warmup_steps, total_steps
        )

        best_val_f1  = 0.0
        best_state   = None
        loss_fn      = nn.CrossEntropyLoss()#nn.CrossEntropyLoss(label_smoothing=0.1)
        history      = {"train_loss": [], "val_f1": [], "val_auroc": []}

        for epoch in range(self.config.blue_epochs_per_round):
            self.model.train()
            epoch_loss = 0.0

            for batch in tqdm(train_loader, desc=f"Epoch {epoch+1}", disable=False):
                input_ids      = batch["input_ids"].to(self.device)
                attention_mask = batch["attention_mask"].to(self.device)
                labels         = batch["label"].to(self.device)
                # print("in loooppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp")
                optimizer.zero_grad()
                # for t in input_ids[:5]:
                #     print(f"  Input IDs: {t.cpu().numpy()[:10]}")  # Print first 10 token IDs of the first 5 samples
                outputs = self.model(input_ids=input_ids,
                                     attention_mask=attention_mask)
                # print(f"  Logits: {outputs.logits[:5].cpu().detach().numpy()} | Labels: {labels[:5].cpu().numpy()}  || Attention Mask: {attention_mask[:5].cpu().numpy()}")
                loss = loss_fn(outputs.logits, labels)
                print(f"  Loss: {loss.item():.4f}")
                
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                has_nan = False
                for p in self.model.parameters():
                    if p.grad is not None and (torch.isnan(p.grad).any() or torch.isinf(p.grad).any()):
                        has_nan = True
                        break

                if has_nan:
                    print("⚠️ NaN/Inf detected in gradients → Skipping optimizer step")
                    optimizer.zero_grad() # Throw away the bad gradients
                else:
                    optimizer.step()      # Safe to update weights
                scheduler.step()
                epoch_loss += loss.item()

            avg_loss = epoch_loss / len(train_loader)
            val_metrics = self.evaluate(val_loader)
            history["train_loss"].append(avg_loss)
            history["val_f1"].append(val_metrics["f1"])
            history["val_auroc"].append(val_metrics["auroc"])

            logger.info(
                f"  Epoch {epoch+1}/{self.config.blue_epochs_per_round} | "
                f"Loss: {avg_loss:.4f} | Val F1: {val_metrics['f1']:.4f} | "
                f"AUROC: {val_metrics['auroc']:.4f}"
            )

            # Early stopping: save best checkpoint
            if val_metrics["f1"] > best_val_f1:
                best_val_f1 = val_metrics["f1"]
                best_state  = {k: v.cpu().clone()
                               for k, v in self.model.state_dict().items()}

        # Restore best weights
        if best_state is not None:
            self.model.load_state_dict(
                {k: v.to(self.device) for k, v in best_state.items()}
            )
        return history

    # ── Inference ─────────────────────────────────────────────────────────────

    @torch.no_grad()
    def predict_proba(self, texts: List[str]) -> np.ndarray:
        """
        Return P(AI-generated) for each text.
        Shape: (N,)
        """
        self.model.eval()
        all_probs = []

        for i in range(0, len(texts), self.config.eval_batch_size):
            batch_texts = texts[i : i + self.config.eval_batch_size]
            enc = self.tokenizer(
                batch_texts,
                max_length=self.config.blue_max_seq_len,
                padding=True,
                truncation=True,
                return_tensors="pt",
            ).to(self.device)
            logits = self.model(**enc).logits          # (B, 2)
            probs  = torch.softmax(logits, dim=-1)[:, 1]  # P(AI)
            all_probs.append(probs.cpu().numpy())

        return np.concatenate(all_probs)

    @torch.no_grad()
    def predict(self, texts: List[str], threshold: float = 0.5) -> np.ndarray:
        """Return binary predictions."""
        return (self.predict_proba(texts) >= threshold).astype(int)

    # ── Evaluation ────────────────────────────────────────────────────────────

    @torch.no_grad()
    def evaluate(self, loader: DataLoader) -> Dict[str, float]:
        """Compute F1, AUROC, Accuracy on a DataLoader."""
        self.model.eval()
        all_labels, all_probs = [], []

        for batch in loader:
            input_ids      = batch["input_ids"].to(self.device)
            attention_mask = batch["attention_mask"].to(self.device)
            labels         = batch["label"].numpy()

            logits = self.model(
                input_ids=input_ids, attention_mask=attention_mask
            ).logits
            probs  = torch.softmax(logits, dim=-1)[:, 1].cpu().numpy()

            all_labels.extend(labels)
            all_probs.extend(probs)

        all_labels = np.array(all_labels)
        all_probs  = np.array(all_probs)
        
        # Replace NaN with 0.5 (neutral probability)
        all_probs = np.nan_to_num(all_probs, nan=0.5)
        
        preds      = (all_probs >= 0.5).astype(int)

        return {
            "f1":       f1_score(all_labels, preds, average="macro"),
            "auroc":    roc_auc_score(all_labels, all_probs),
            "accuracy": accuracy_score(all_labels, preds),
        }

    def evaluate_on_samples(self, samples: List[TextSample]) -> Dict[str, float]:
        """Convenience wrapper: evaluate directly on TextSample list."""
        loader = make_dataloader(
            samples, self.tokenizer,
            self.config.eval_batch_size, self.config.blue_max_seq_len,
            shuffle=False
        )
        return self.evaluate(loader)

    # ── Evasion rate ──────────────────────────────────────────────────────────

    def evasion_rate(self, ai_texts: List[str]) -> float:
        """
        Fraction of AI texts where Blue is fooled (predicts human).
        Used to track Red agent's effectiveness per round.
        """
        probs = self.predict_proba(ai_texts)
        fooled = (probs < 0.5).sum()
        return fooled / len(ai_texts)

    # ── Checkpointing ─────────────────────────────────────────────────────────

    def save(self, path: str):
        os.makedirs(path, exist_ok=True)
        self.model.save_pretrained(path)
        self.tokenizer.save_pretrained(path)
        logger.info(f"Blue agent saved to {path}")

    def load(self, path: str):
        self.model = AutoModelForSequenceClassification.from_pretrained(
            path, num_labels=2
        ).to(self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(path)
        logger.info(f"Blue agent loaded from {path}")

    def get_frozen_copy(self) -> "BlueAgent":
        """
        Return a frozen (eval-only) copy for Red agent training.
        Added to frozen checkpoint pool P each round.
        """
        copy = BlueAgent.__new__(BlueAgent)
        copy.config    = self.config
        copy.device    = self.device
        copy.tokenizer = self.tokenizer
        copy.model     = type(self.model).from_pretrained(
            self.config.blue_model_name, num_labels=2
        ).to(self.device)
        copy.model.load_state_dict(self.model.state_dict())
        copy.model.eval()
        for p in copy.model.parameters():
            p.requires_grad = False
        return copy
