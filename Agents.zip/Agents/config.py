# cobra/config.py
"""
COBRA: Co-evolutionary Blue-Red Agents for AI-Generated Text Detection
Configuration dataclass
"""

from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class COBRAConfig:
    # ── Co-evolution ──────────────────────────────────────────────
    num_rounds: int = 8 #10                  # K rounds of co-evolution
    seed: int = 42

    # ── Blue Agent (DeBERTa detector) ─────────────────────────────
    blue_model_name: str = "microsoft/deberta-v3-small" # "microsoft/deberta-v3-large"
    blue_lr: float = 1e-6 #5e-6 
    blue_weight_decay: float = 0.01
    blue_epochs_per_round: int = 5 #5
    blue_batch_size: int = 8    #8
    blue_max_seq_len: int = 512
    blue_warmup_ratio: float = 0.1

    # ── Red Agent (T5 evader) ──────────────────────────────────────
    # red_model_name: str = "t5-large"
    red_model_name: str = "google/flan-t5-large" # "google/flan-t5-xl"
    red_lr: float = 2e-5 #5e-7
    red_ppo_epochs: int = 4
    red_ppo_clip: float = 0.05
    red_batch_size: int = 8
    red_kl_coef: float = 0.2            # KL penalty vs. base model
    red_reward_lambda: float = 0.3       # semantic similarity weight
    red_semantic_threshold: float = 0.85 # min cosine sim to accept sample
    red_max_new_tokens: int = 128 #256
    red_temperature: float = 0.4

    # ── Diversity Buffer ──────────────────────────────────────────
    buffer_max_size: int = 1000
    buffer_clusters: int = 10
    buffer_samples_per_cluster: int = 20

    # ── Evaluation ────────────────────────────────────────────────
    eval_batch_size: int = 1
    zero_shot_llms: List[str] = field(default_factory=lambda: [
        "gpt-4", "gemini-1.5-pro", "mistral-7b", "command-r"
    ])

    # ── Paths ─────────────────────────────────────────────────────
    output_dir: str = "./cobra_outputs"
    checkpoint_dir: str = "./cobra_outputs/checkpoints"
    log_dir: str = "./cobra_outputs/logs"
    buffer_path: str = "./cobra_outputs/diversity_buffer.pkl"
    cache_dir: str = "./hf_cache"
