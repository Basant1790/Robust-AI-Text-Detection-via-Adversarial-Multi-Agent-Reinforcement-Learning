# cobra/red_agent.py
"""
Red Agent: T5-large fine-tuned via PPO to evade the Blue agent.
Reward = evasion signal - lambda * semantic_similarity_penalty
Hard constraint: drop samples where cosine_sim < threshold
"""

import os
import logging
import random
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from transformers import T5ForConditionalGeneration, T5Tokenizer
from sentence_transformers import SentenceTransformer

from cobra.config import COBRAConfig
from cobra.blue_agent import BlueAgent
from cobra.data import TextSample

# Prevents CUDA memory fragmentation OOM
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

logger = logging.getLogger(__name__)


class RedAgent:
    """
    T5-large evader trained with PPO against a mixture of frozen Blue checkpoints.
    """

    def __init__(self, config: COBRAConfig, device: torch.device):
        self.config = config
        self.device = device

        logger.info(f"Loading Red agent: {config.red_model_name}")
        self.tokenizer = T5Tokenizer.from_pretrained(config.red_model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(
            config.red_model_name
        ).to(device)

        # Reference model for KL divergence penalty (stays frozen)
        self.ref_model = T5ForConditionalGeneration.from_pretrained(
            config.red_model_name
        ).to(device)
        for p in self.ref_model.parameters():
            p.requires_grad = False
        self.ref_model.eval()

        # Sentence-BERT for semantic similarity (on CPU to save GPU RAM)
        logger.info("Loading sentence-BERT for semantic constraint...")
        self.sbert = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")

        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=config.red_lr
        )

    # ── Generation ────────────────────────────────────────────────────────────

    def _build_prompt(self, text: str) -> str:
        strategies = [
            "paraphrase the following text to sound more natural and human-like:",
            "rewrite the following with varied sentence structures and informal tone:",
            "rephrase the following using simpler vocabulary and conversational style:",
            "restructure the following text with different sentence order and phrasing:",
        ]
        return f"{random.choice(strategies)} {text}"

    def generate(self, texts: List[str]) -> List[str]:
        """Generate perturbed versions of input texts."""
        self.model.eval()
        results = []

        for i in range(0, len(texts), self.config.red_batch_size):
            batch = texts[i : i + self.config.red_batch_size]
            prompts = [self._build_prompt(t) for t in batch]

            enc = self.tokenizer(
                prompts,
                max_length=self.config.blue_max_seq_len,
                padding=True,
                truncation=True,
                return_tensors="pt",
            ).to(self.device)

            try:
                with torch.no_grad():
                    out_ids = self.model.generate(
                        **enc,
                        max_new_tokens=self.config.red_max_new_tokens,
                        do_sample=True,       # MUST be True — False causes NaN probs
                        temperature=self.config.red_temperature,
                        top_k=50,             # Prevents degenerate probability distributions
                        top_p=0.95,
                    )
                decoded = self.tokenizer.batch_decode(out_ids, skip_special_tokens=True)
            except Exception as e:
                logger.warning(f"generate() failed: {e} — using original texts as fallback")
                decoded = batch  # fallback: return originals unchanged

            results.extend(decoded)

        return results

    # ── Semantic similarity ───────────────────────────────────────────────────

    @torch.no_grad()
    def semantic_similarity(
        self, originals: List[str], perturbed: List[str]
    ) -> np.ndarray:
        emb_orig = self.sbert.encode(originals, convert_to_tensor=True, show_progress_bar=False)
        emb_pert = self.sbert.encode(perturbed, convert_to_tensor=True, show_progress_bar=False)
        sims = F.cosine_similarity(emb_orig, emb_pert).cpu().numpy()
        return sims

    # ── Reward computation ────────────────────────────────────────────────────

    def compute_rewards(
        self,
        originals: List[str],
        perturbed: List[str],
        blue_pool: List[BlueAgent],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        # Move Blue pool agents to GPU for scoring, then back to CPU
        for agent in blue_pool:
            agent.model.to(self.device)

        all_probs = np.stack(
            [agent.predict_proba(perturbed) for agent in blue_pool], axis=0
        )

        for agent in blue_pool:
            agent.model.cpu()
        torch.cuda.empty_cache()

        blue_probs = all_probs.mean(axis=0)

        # Sanitize: NaN/inf probs (from untrained Blue) → 0.5 (neutral)
        blue_probs = np.nan_to_num(blue_probs, nan=0.5, posinf=1.0, neginf=0.0)
        blue_probs = np.clip(blue_probs, 1e-6, 1.0 - 1e-6)

        evasion_reward = -np.log(blue_probs + 1e-8)

        sims = self.semantic_similarity(originals, perturbed)
        sims = np.nan_to_num(sims, nan=0.0)

        valid_mask = sims >= self.config.red_semantic_threshold
        rewards = evasion_reward + self.config.red_reward_lambda * sims
        rewards[~valid_mask] = -10.0

        return rewards, sims, valid_mask

    # ── Log prob computation ──────────────────────────────────────────────────

    def _compute_log_probs(
        self,
        model: T5ForConditionalGeneration,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        decoder_input_ids: torch.Tensor,
    ) -> torch.Tensor:
        """Compute per-sequence log probabilities. Frees intermediates immediately."""
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            decoder_input_ids=decoder_input_ids,
        )
        log_probs = F.log_softmax(outputs.logits.float(), dim=-1)   # float32 for stability
        token_log_probs = log_probs.gather(
            2, decoder_input_ids.unsqueeze(-1)
        ).squeeze(-1)
        result = token_log_probs.sum(dim=-1)   # save result BEFORE del
        del outputs, log_probs, token_log_probs
        torch.cuda.empty_cache()
        return result

    # ── PPO Training Step ─────────────────────────────────────────────────────

    def ppo_step(
        self,
        ai_samples: List[TextSample],
        blue_pool: List[BlueAgent],
        round_num: int,
    ) -> dict:
        self.model.train()
        texts = [s.text for s in ai_samples]

        total_loss    = 0.0
        total_evasion = 0.0
        total_samples = 0
        n_batches     = 0

        print("🔥 Starting PPO epochs")
        for epoch in range(self.config.red_ppo_epochs):
            random.shuffle(texts)

            for i in range(0, len(texts), self.config.red_batch_size):
                batch_texts = texts[i : i + self.config.red_batch_size]
                if not batch_texts:
                    continue

                prompts = [self._build_prompt(t) for t in batch_texts]

                enc = self.tokenizer(
                    prompts,
                    max_length=self.config.blue_max_seq_len,
                    padding=True, truncation=True,
                    return_tensors="pt",
                ).to(self.device)

                if enc["input_ids"].numel() == 0:
                    continue

                # ── Generate perturbed texts ──────────────────────────────
                try:
                    with torch.no_grad():
                        out_ids = self.model.generate(
                            **enc,
                            max_new_tokens=self.config.red_max_new_tokens,
                            do_sample=True,       # CRITICAL: must be True
                            temperature=self.config.red_temperature,
                            top_k=50,
                            top_p=0.95,
                        )
                except Exception as e:
                    logger.warning(f"PPO generation failed batch {i}: {e}")
                    torch.cuda.empty_cache()
                    continue

                perturbed = self.tokenizer.batch_decode(out_ids, skip_special_tokens=True)

                # Filter empty outputs
                clean_perturbed = [
                    t if (t and len(t.strip()) > 5) else batch_texts[j]
                    for j, t in enumerate(perturbed)
                ]

                # ── Compute rewards ───────────────────────────────────────
                with torch.no_grad():
                    rewards, sims, valid_mask = self.compute_rewards(
                        batch_texts, clean_perturbed, blue_pool
                    )

                rewards_t = torch.tensor(rewards, dtype=torch.float32, device=self.device)

                # Guard against all-same rewards (std=0 → NaN after normalize)
                if rewards_t.std() > 1e-8:
                    rewards_t = (rewards_t - rewards_t.mean()) / (rewards_t.std() + 1e-8)
                else:
                    rewards_t = rewards_t - rewards_t.mean()

                # ── Tokenize decoder outputs ──────────────────────────────
                dec_enc = self.tokenizer(
                    clean_perturbed,
                    max_length=self.config.red_max_new_tokens,
                    padding=True, truncation=True,
                    return_tensors="pt",
                ).to(self.device)
                decoder_input_ids = dec_enc["input_ids"]

                # ── PPO loss ──────────────────────────────────────────────
                new_log_probs = self._compute_log_probs(
                    self.model, enc["input_ids"], enc["attention_mask"], decoder_input_ids
                )

                with torch.no_grad():
                    old_log_probs = self._compute_log_probs(
                        self.ref_model, enc["input_ids"], enc["attention_mask"], decoder_input_ids
                    )

                ratio   = torch.exp(new_log_probs - old_log_probs)
                clipped = torch.clamp(ratio,
                                      1 - self.config.red_ppo_clip,
                                      1 + self.config.red_ppo_clip)
                ppo_loss   = -torch.min(ratio * rewards_t, clipped * rewards_t).mean()
                kl_penalty = (new_log_probs - old_log_probs).mean()
                loss       = ppo_loss + self.config.red_kl_coef * kl_penalty

                if torch.isnan(loss) or torch.isinf(loss):
                    logger.warning("NaN/inf PPO loss, skipping batch")
                    self.optimizer.zero_grad()
                    torch.cuda.empty_cache()
                    continue

                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                self.optimizer.step()

                total_loss    += loss.item()
                total_evasion += float(valid_mask.sum())
                total_samples += len(batch_texts)
                n_batches     += 1

                torch.cuda.empty_cache()

        avg_loss     = total_loss / max(1, n_batches)
        evasion_rate = total_evasion / max(1, total_samples)

        logger.info(
            f"  [Round {round_num}] Red PPO done | "
            f"Loss: {avg_loss:.4f} | Evasion rate: {evasion_rate:.3f}"
        )
        return {"loss": avg_loss, "evasion_rate": float(evasion_rate)}

    # ── Collect evasion samples ───────────────────────────────────────────────

    def collect_evasion_samples(
        self,
        ai_samples: List[TextSample],
        blue_agent: BlueAgent,
        max_collect: int = 2000,
    ) -> List[TextSample]:
        texts     = [s.text for s in ai_samples]
        perturbed = self.generate(texts)
        sims      = self.semantic_similarity(texts, perturbed)
        sims      = np.nan_to_num(sims, nan=0.0)

        evasion_samples = []
        for orig_s, pert_text, sim_score in zip(ai_samples, perturbed, sims):
            if sim_score  <self.config.red_semantic_threshold:
                print(sim_score)
                continue
            evasion_samples.append(TextSample(
                text=pert_text, label=1,
                source_llm=f"red_agent_{orig_s.source_llm}",
                domain=orig_s.domain,
            ))

        if evasion_samples:
            pert_texts = [s.text for s in evasion_samples]
            blue_preds = blue_agent.predict(pert_texts)
            successful = [s for s, p in zip(evasion_samples, blue_preds) if p == 0]
        else:
            successful = []

        logger.info(
            f"  Red collected {len(successful)} successful evasion samples "
            f"(from {len(ai_samples)} AI texts)"
        )
        return successful[:max_collect]
