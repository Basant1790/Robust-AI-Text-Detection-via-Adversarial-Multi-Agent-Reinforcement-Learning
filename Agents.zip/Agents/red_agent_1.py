# cobra/red_agent.py
"""
Red Agent: T5-large fine-tuned via PPO to evade the Blue agent.
Reward = evasion signal - lambda * semantic_similarity_penalty
Hard constraint: drop samples where cosine_sim < threshold
"""

import logging
import random
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from transformers import T5ForConditionalGeneration, T5Tokenizer
from sentence_transformers import SentenceTransformer
# from transformers import AutoModelForSeq2SeqLM
# from transformers import (
#     AutoTokenizer,
#     AutoModelForSeq2SeqLM,   # ✅ ADD THIS
# )
from cobra.config import COBRAConfig
from cobra.blue_agent import BlueAgent
from cobra.data import TextSample

logger = logging.getLogger(__name__)


class RedAgent:
    """
    T5-large evader trained with PPO against a mixture of frozen Blue checkpoints.

    Action: Transform AI-generated text x → x̃ such that:
      - Blue assigns low AI probability to x̃
      - Semantic similarity sim(x, x̃) >= threshold  (hard constraint)

    Reward: r(x, x̃) = -log(Blue(x̃)) + λ * sim(x, x̃)
    """

    def __init__(self, config: COBRAConfig, device: torch.device):
        self.config = config
        self.device = device

        logger.info(f"Loading Red agent: {config.red_model_name}")
        self.tokenizer = T5Tokenizer.from_pretrained(config.red_model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(
            config.red_model_name
        ).to(device)

        # Reference model for KL divergence penalty (stays frozen)
        self.ref_model = T5ForConditionalGeneration.from_pretrained(
            config.red_model_name
        ).to(device)
        for p in self.ref_model.parameters():
            p.requires_grad = False
        self.ref_model.eval()

        # Sentence-BERT for semantic similarity
        logger.info("Loading sentence-BERT for semantic constraint...")
        self.sbert = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")

        self.optimizer = torch.optim.AdamW(
            self.model.parameters(), lr=config.red_lr
        )

    # ── Generation ────────────────────────────────────────────────────────────

    def _build_prompt(self, text: str) -> str:
        """
        T5 instruction prompt for paraphrase + style-shift.
        Covers four action types: lexical, syntactic, style, discourse.
        """
        strategies = [
            "paraphrase the following text to sound more natural and human-like:",
            "rewrite the following with varied sentence structures and informal tone:",
            "rephrase the following using simpler vocabulary and conversational style:",
            "restructure the following text with different sentence order and phrasing:",
        ]
        strategy = random.choice(strategies)
        return f"{strategy} {text}"

    def generate(self, texts: List[str]) -> List[str]:
        """
        Generate perturbed versions of input texts.
        Returns raw decoded strings (no semantic filtering here).
        """
        self.model.eval()
        results = []

        for i in range(0, len(texts), self.config.red_batch_size):
            batch = texts[i : i + self.config.red_batch_size]
            prompts = [self._build_prompt(t) for t in batch]

            enc = self.tokenizer(
                prompts,
                max_length=self.config.blue_max_seq_len,
                padding=True,
                truncation=True,
                return_tensors="pt",
            ).to(self.device)

            with torch.no_grad():
                out_ids = self.model.generate(
                    **enc,
                    max_new_tokens=self.config.red_max_new_tokens,
                    temperature=self.config.red_temperature,
                    do_sample=True,
                    top_p=0.9,
                    top_k=50,
                )
            decoded = self.tokenizer.batch_decode(
                out_ids, skip_special_tokens=True
            )
            results.extend(decoded)

        return results

    # ── Semantic similarity ───────────────────────────────────────────────────

    @torch.no_grad()
    def semantic_similarity(
        self, originals: List[str], perturbed: List[str]
    ) -> np.ndarray:
        """
        Cosine similarity between sentence-BERT embeddings.
        Shape: (N,)
        """
        emb_orig  = self.sbert.encode(originals, convert_to_tensor=True,
                                       show_progress_bar=False)
        emb_pert  = self.sbert.encode(perturbed, convert_to_tensor=True,
                                       show_progress_bar=False)
        sims = F.cosine_similarity(emb_orig, emb_pert).cpu().numpy()
        return sims

    # ── Reward computation ────────────────────────────────────────────────────

    def compute_rewards(
        self,
        originals: List[str],
        perturbed: List[str],
        blue_pool: List[BlueAgent],
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute PPO rewards for a batch of (original, perturbed) pairs.

        reward(x, x̃) = -log(Blue_mixture(x̃)) + λ * sim(x, x̃)
        Hard constraint: sim < threshold → reward = -inf (sample masked)

        Returns:
            rewards:     (N,) final scalar rewards
            sims:        (N,) semantic similarity scores
            valid_mask:  (N,) boolean mask (False = constraint violated)
        """
        # Average Blue probability across frozen pool (mixture)
        all_probs = np.stack(
            [agent.predict_proba(perturbed) for agent in blue_pool], axis=0
        )  # (num_agents, N)
        blue_probs = all_probs.mean(axis=0)           # (N,)

        # Evasion reward: Red wins when Blue assigns low P(AI)
        evasion_reward = -np.log(blue_probs + 1e-8)   # (N,)

        # Semantic similarity
        sims = self.semantic_similarity(originals, perturbed)  # (N,)

        # Hard constraint mask
        valid_mask = sims >= self.config.red_semantic_threshold

        # Final reward
        rewards = evasion_reward + self.config.red_reward_lambda * sims
        rewards[~valid_mask] = -10.0                  # penalize constraint violation

        # 🔥 FIX: clip FULL array (not single reward)
        rewards = np.clip(rewards, -5, 5)

        # 🔥 FIX: replace NaN/inf safely
        rewards = np.nan_to_num(rewards, nan=0.0, posinf=5.0, neginf=-5.0)

        return rewards, sims, valid_mask

    # ── PPO Training Step ─────────────────────────────────────────────────────

    def _compute_log_probs(
        self,
        model: T5ForConditionalGeneration,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        decoder_input_ids: torch.Tensor,
    ) -> torch.Tensor:
        """Compute per-token log probabilities."""
        outputs = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            decoder_input_ids=decoder_input_ids,
        )
        log_probs = F.log_softmax(outputs.logits, dim=-1)  # (B, T, V)
        # Gather log probs of actual tokens
        token_log_probs = log_probs.gather(
            2, decoder_input_ids.unsqueeze(-1)
        ).squeeze(-1) # (B, T)
        result = token_log_probs.sum(dim=-1) 
        del outputs, log_probs, token_log_probs  # free memory immediately
        torch.cuda.empty_cache()
        return result                # (B,)  sequence log prob

    def ppo_step(
        self,
        ai_samples: List[TextSample],
        blue_pool: List[BlueAgent],
        round_num: int,
    ) -> dict:
        """
        Run one round of PPO training for the Red agent.

        Steps:
          1. Generate perturbed texts (old policy)
          2. Compute rewards
          3. PPO clipped objective + KL penalty
          4. Update Red model
        """
        self.model.train()
        texts = [s.text for s in ai_samples]
        
        total_loss       = 0.0
        total_evasion    = 0.0
        total_valid      = 0
        total_samples    = 0
        print("🔥 Starting PPPPO epochs")
        print(f"Total AI samples for PPO: {len(texts)}")
        for epoch in range(self.config.red_ppo_epochs):
            random.shuffle(texts)
            
            for i in range(0, len(texts), self.config.red_batch_size):
                # print("currently in second for loop with batch index:", i)
                batch_texts = texts[i : i + self.config.red_batch_size]
                prompts     = [self._build_prompt(t) for t in batch_texts]
                # print("tokenizing prompts")
                # Tokenize prompts (encoder input)
                enc = self.tokenizer(
                    prompts,
                    max_length=self.config.blue_max_seq_len,
                    padding=True, truncation=True,
                    return_tensors="pt",
                ).to(self.device)

                if enc["input_ids"].numel() == 0:
                    print("⚠️ Empty input, skipping")
                    continue

                if torch.isnan(enc["input_ids"]).any():
                    print("⚠️ NaN in input_ids")
                    continue

                # Generate with current (new) policy
                # print("generating perturbed texts")

                    
                out_ids = self.model.generate(
                    **enc,
                    max_new_tokens=self.config.red_max_new_tokens,
                    do_sample=True,
                    temperature=self.config.red_temperature,
                    top_p=0.90,
                    top_k=30,
                    repetition_penalty=1.2,
                )

                # print("text successfully generated")
                # print("decoding perturbed texts")
                perturbed = self.tokenizer.batch_decode(
                    out_ids, skip_special_tokens=True
                )
                # print("len(perturbed):", len(perturbed))
                


                # 🔥 DEBUG PRINT
                # print("\nllllllllllllllllllllllllllllllllllllllllllllllllllllllll" + "="*50)
                # print("🔥 RED GENERATED TEXT (BATCH)")
                # for i, t in enumerate(perturbed):
                #     print(f"\n[{i}] {t[:200]}")   # print first 200 chars
                # print("="*50 + "\n")


                clean_perturbed = []
                valid_mask = []

                for text in perturbed:
                    if text and len(text.strip()) > 5:   # 🔥 filter empty/short
                        clean_perturbed.append(text)
                        valid_mask.append(True)
                    else:
                        clean_perturbed.append("dummy text")  # safe fallback
                        valid_mask.append(False)

                # Decode output for reward computation (no grad needed here)
                # print("computing rewards")
                with torch.no_grad():
                    rewards, sims, valid_mask = self.compute_rewards(
                        batch_texts, clean_perturbed, blue_pool
                    )
                # print(f"Rewards computed for batch {i // self.config.red_batch_size + 1}")
                rewards_t = torch.tensor(
                    rewards, dtype=torch.float32, device=self.device
                )

                # Normalize rewards (running mean/std)
                # print("normalizing rewards")
                rewards_t = (rewards_t - rewards_t.mean()) / (rewards_t.std() + 1e-8)

                # Pad decoder inputs for log prob computation
                # print("tokenizing perturbed texts for log probs")
                dec_enc = self.tokenizer(
                    perturbed,
                    max_length=self.config.red_max_new_tokens,
                    padding=True, truncation=True,
                    return_tensors="pt",
                ).to(self.device)
                decoder_input_ids = dec_enc["input_ids"]
                # print("computing log probabilities for PPO loss")
                # # New policy log probs
                new_log_probs = self._compute_log_probs(
                    self.model,
                    enc["input_ids"], enc["attention_mask"],
                    decoder_input_ids,
                )  # (B,)

                # Old policy log probs (reference model, no grad)
                # print("computing log probabilities for KL penalty")
                with torch.no_grad():
                    old_log_probs = self._compute_log_probs(
                        self.ref_model,
                        enc["input_ids"], enc["attention_mask"],
                        decoder_input_ids,
                    )

                # PPO clipped surrogate loss
                # print("computing PPO loss and updating model")
                ratio       = torch.exp(new_log_probs - old_log_probs)
                clipped     = torch.clamp(
                    ratio,
                    1 - self.config.red_ppo_clip,
                    1 + self.config.red_ppo_clip,
                )
                ppo_loss    = -torch.min(ratio * rewards_t,
                                         clipped * rewards_t).mean()

                # KL divergence penalty (keep Red close to base model)
                kl_penalty  = (new_log_probs - old_log_probs).mean()
                loss        = ppo_loss + self.config.red_kl_coef * kl_penalty
                # print("backpropagating PPO loss")
                if torch.isnan(loss) or torch.isinf(loss):
                 print("❌ NaN/inf PPO loss, lala skip ho gya ye toh")
                 continue
                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                self.optimizer.step()

                total_loss    += loss.item()
                total_evasion += valid_mask.sum()
                total_valid   += valid_mask.sum()
                total_samples += len(batch_texts)
        # print("🔥 Finished PPO epochs")
        avg_loss    = total_loss / (self.config.red_ppo_epochs * max(1, len(texts) // self.config.red_batch_size))
        evasion_rate = total_evasion / max(1, total_samples)

        logger.info(
            f"  [Round {round_num}] Red PPO done | "
            f"Loss: {avg_loss:.4f} | Evasion rate: {evasion_rate:.3f}"
        )
        return {"loss": avg_loss, "evasion_rate": float(evasion_rate)}

    # ── Collect evasion samples ───────────────────────────────────────────────

    def collect_evasion_samples(
        self,
        ai_samples: List[TextSample],
        blue_agent: BlueAgent,
        max_collect: int = 2000,
    ) -> List[TextSample]:
        """
        Generate perturbed samples and return those where Blue is fooled.
        Used to populate the diversity buffer.
        """
        texts     = [s.text for s in ai_samples]
        perturbed = self.generate(texts)
        sims      = self.semantic_similarity(texts, perturbed)

        evasion_samples = []
        for orig_s, pert_text, sim_score in zip(ai_samples, perturbed, sims):
            print(f" Sim: {sim_score:.3f}| Original: {orig_s.text[:100]} | Perturbed: {pert_text[:100]}")
            if sim_score < self.config.red_semantic_threshold:
                print("  ⚠️ Sample failed semantic constraint, skipping")
                continue
            evasion_samples.append(TextSample(
                text=pert_text, label=1,        # still AI-generated (just perturbed)
                source_llm=f"red_agent_{orig_s.source_llm}",
                domain=orig_s.domain,
            ))

        # Only keep ones Blue actually misclassifies
        if evasion_samples:
            pert_texts  = [s.text for s in evasion_samples]
            blue_preds  = blue_agent.predict(pert_texts)
            successful  = [s for s, p in zip(evasion_samples, blue_preds) if p == 0]
        else:
            successful = []

        logger.info(
            f"  Red collected {len(successful)} successful evasion samples "
            f"(from {len(ai_samples)} AI texts)"
        )
        return successful[:max_collect]
