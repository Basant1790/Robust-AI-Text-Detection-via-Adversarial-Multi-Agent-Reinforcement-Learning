# cobra/data.py
"""
Dataset loading, preprocessing and splitting utilities.
Supports: HC3, RAID, M4, MAGE
"""

import os
import csv
import sys
import json
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import PreTrainedTokenizer

# Increase CSV field size limit for large RAID dataset
csv.field_size_limit(sys.maxsize)


# ── Sample dataclass ──────────────────────────────────────────────────────────

@dataclass
class TextSample:
    text: str
    label: int          # 1 = AI-generated, 0 = human
    source_llm: str     # e.g. "gpt-4", "human", "llama-3"
    domain: str         # e.g. "news", "academic", "social"
    sample_id: str = ""


# ── PyTorch Dataset ───────────────────────────────────────────────────────────

class DetectionDataset(Dataset):
    """Tokenized dataset for Blue agent training / evaluation."""

    def __init__(
        self,
        samples: List[TextSample],
        tokenizer: PreTrainedTokenizer,
        max_length: int = 512,
    ):
        self.samples   = samples
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        sample   = self.samples[idx]
        encoding = self.tokenizer(
            sample.text,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )
        #from gemini
        cls_id = self.tokenizer.cls_token_id
        if cls_id is not None and encoding["input_ids"][0, 0] != cls_id:
            encoding["input_ids"][0, 0] = cls_id
        #--------------
        
        return {
            "input_ids":      encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "label":          torch.tensor(sample.label, dtype=torch.long),
        }


# ── Loader functions ──────────────────────────────────────────────────────────

def load_hc3(data_path: str) -> List[TextSample]:
    """Load HC3 dataset (human-ChatGPT comparison corpus)."""
    samples = []
    with open(data_path, "r", encoding="utf-8") as f:
        for line in f:
            item = json.loads(line.strip())
            for ans in item.get("human_answers", []):
                if ans.strip():
                    samples.append(TextSample(
                        text=ans.strip(), label=0,
                        source_llm="human",
                        domain=item.get("source", "general"),
                    ))
            for ans in item.get("chatgpt_answers", []):
                if ans.strip():
                    samples.append(TextSample(
                        text=ans.strip(), label=1,
                        source_llm="gpt-3.5",
                        domain=item.get("source", "general"),
                    ))
    return samples


def load_raid(data_path: str, split: str = "train") -> List[TextSample]:
    """Load RAID dataset (multi-LLM, multi-domain)."""
    samples  = []
    filepath = os.path.join(data_path, f"{split}.csv")
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            samples.append(TextSample(
                text=row["generation"],
                label=0 if row["model"] == "human" else 1,
                source_llm=row.get("model", "unknown"),
                domain=row.get("domain", "general"),
                sample_id=row.get("id", ""),
            ))
    return samples


def load_m4(data_path: str) -> List[TextSample]:
    """Load M4 dataset (multilingual multi-generator)."""
    samples = []
    for fname in os.listdir(data_path):
        if not fname.endswith(".jsonl"):
            continue
        with open(os.path.join(data_path, fname), "r", encoding="utf-8") as f:
            for line in f:
                item = json.loads(line.strip())
                samples.append(TextSample(
                    text=item["text"],
                    label=item["label"],            # 0=human, 1=AI
                    source_llm=item.get("model", "unknown"),
                    domain=item.get("domain", "general"),
                ))
    return samples


def load_mage(data_path: str) -> List[TextSample]:
    """Load MAGE dataset (zero-shot eval set)."""
    samples = []
    with open(data_path, "r", encoding="utf-8") as f:
        for line in f:
            item = json.loads(line.strip())
            samples.append(TextSample(
                text=item["text"],
                label=item["label"],
                source_llm=item.get("model", "unknown"),
                domain=item.get("domain", "general"),
            ))
    return samples


# ── Split utilities ───────────────────────────────────────────────────────────

def train_val_test_split(
    samples: List[TextSample],
    train_ratio: float = 0.8,
    val_ratio: float   = 0.1,
    seed: int          = 42,
) -> Tuple[List[TextSample], List[TextSample], List[TextSample]]:
    """Stratified split preserving label balance."""
    random.seed(seed)
    ai_samples    = [s for s in samples if s.label == 1]
    human_samples = [s for s in samples if s.label == 0]

    def split_list(lst):
        random.shuffle(lst)
        n = len(lst)
        t = int(n * train_ratio)
        v = int(n * (train_ratio + val_ratio))
        return lst[:t], lst[t:v], lst[v:]

    ai_tr, ai_v, ai_te   = split_list(ai_samples)
    hu_tr, hu_v, hu_te   = split_list(human_samples)
    return ai_tr + hu_tr, ai_v + hu_v, ai_te + hu_te


def balance_dataset(
    samples: List[TextSample], seed: int = 42
) -> List[TextSample]:
    """Oversample minority class to 1:1 ratio."""
    random.seed(seed)
    ai    = [s for s in samples if s.label == 1]
    human = [s for s in samples if s.label == 0]
    if len(ai) > len(human):
        human = human + random.choices(human, k=len(ai) - len(human))
    else:
        ai = ai + random.choices(ai, k=len(human) - len(ai))
    combined = ai + human
    random.shuffle(combined)
    return combined


def make_dataloader(
    samples: List[TextSample],
    tokenizer: PreTrainedTokenizer,
    batch_size: int,
    max_length: int  = 512,
    shuffle: bool    = True,
) -> DataLoader:
    dataset = DetectionDataset(samples, tokenizer, max_length)
    return DataLoader(
        dataset, batch_size=batch_size, shuffle=shuffle,
        num_workers=4, pin_memory=True,
    )