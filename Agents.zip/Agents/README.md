# COBRA 🐍
## Co-evolutionary Blue-Red Agents for AI-Generated Text Detection

---

## Project Structure

```
cobra/
├── config.py           # All hyperparameters in one dataclass
├── data.py             # Dataset loading (HC3, RAID, M4, MAGE)
├── blue_agent.py       # DeBERTa-v3-large detector + training loop
├── red_agent.py        # T5-large PPO evader + semantic constraint
├── diversity_buffer.py # Cluster-based evasion sample buffer
├── trainer.py          # Co-evolution loop (Algorithm 1)
├── evaluate.py         # Metrics, baselines, ablation runner
├── main.py             # CLI entry point
└── requirements.txt
```

---

## Quickstart

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Prepare data directory
mkdir -p data/hc3 data/raid data/m4 data/mage
# Place HC3 .jsonl, RAID .csv, M4 .jsonl, MAGE .jsonl in respective folders

# 3. Train COBRA (10 co-evolution rounds)
python -m cobra.main --mode train --data_dir ./data --output_dir ./outputs

# 4. Evaluate a saved checkpoint
python -m cobra.main --mode eval \
  --checkpoint ./outputs/checkpoints/blue_final \
  --data_dir ./data

# 5. Run ablations
python -m cobra.main --mode ablate --data_dir ./data

# 6. Regenerate plots from saved logs
python -m cobra.main --mode plot --output_dir ./outputs
```

---

## Key Hyperparameters (cobra/config.py)

| Parameter | Default | Description |
|---|---|---|
| `num_rounds` | 10 | Co-evolution rounds K |
| `red_semantic_threshold` | 0.85 | Min cosine sim for Red outputs |
| `red_reward_lambda` | 0.3 | Semantic similarity reward weight |
| `red_ppo_clip` | 0.2 | PPO clipping parameter ε |
| `buffer_max_size` | 10,000 | Diversity buffer capacity |
| `buffer_clusters` | 20 | K-Means clusters per round |

---

## Outputs

After training, `outputs/` contains:
- `checkpoints/blue_round_k/` — Blue checkpoint after each round
- `checkpoints/blue_final/`   — Final Blue detector
- `logs/history.json`         — Per-round metrics
- `logs/final_report.json`    — Full evaluation report
- `logs/coevolution_dynamics.png` — Figure 2 (co-evolution curves)
- `logs/zero_shot_radar.png`      — Figure 3 (zero-shot radar chart)
- `diversity_buffer.pkl`      — Saved diversity buffer

---

## Citation

```bibtex
@inproceedings{cobra2026,
  title     = {COBRA: Co-evolutionary Blue-Red Agents for Zero-Shot 
               Generalization in AI-Generated Text Detection},
  booktitle = {Proceedings of ACL 2026},
  year      = {2026}
}
```
